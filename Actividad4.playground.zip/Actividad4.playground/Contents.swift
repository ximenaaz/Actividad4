import UIKit

//Declaramos nuestras variables
var datos = [3,6,9,2,4,1]

//Recorrido de nuestro array
for dataMenCinco in datos {
    if dataMenCinco < 5{
        print("Valores menores a cinco: \(dataMenCinco)")
    }
}

// Funcion suma
func suma (n1: Int, n2:Int)-> Int {
    return n1 + n2;
}
let resultSuma = suma(n1: 7, n2: 9)
print ("El resultado de la suma es: \(resultSuma)")

//Funcion de potencia
func potencia (nb: Double, p:Double)->Double {
    return pow(nb, p)
}
let resultPotencia = potencia(nb: 5, p: 5)
print ("El resultado de la potencia es: \(resultPotencia)")


//Enumeracion con los meses del año
enum meses{
    case Enero
    case Febrero
    case Marzo
    case Abril
    case Mayo
    case Junio
    case Julio
    case Agosto
    case Septiembre
    case Octubre
    case Noviembre
    case Diciembre
}


